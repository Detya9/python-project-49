#!/usr/bin/env python3
from brain_games.games.brains import brains
from brain_games.games.even_game import even


def main():
    brains(even)


if __name__ == '__main__':
    main()
