### Hexlet tests and linter status:
[![Actions Status](https://github.com/Detya9/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Detya9/python-project-49/actions)
<a href="https://codeclimate.com/github/Detya9/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f946a3d0094fac015ba/maintainability" /></a>

### asciinema for brain games
[asciinema for brain-even](https://asciinema.org/a/G9h8lfhQs4eIKrBf4IClHgW3Z) "Ссылка на asciinema"

<a href="https://asciinema.org/a/YK3FvcxzaOu0Xvec6yBzc1AfX" target="_blank"><img src="https://asciinema.org/a/YK3FvcxzaOu0Xvec6yBzc1AfX.svg" /></a>

<a href="https://asciinema.org/a/BBxuvJnfnCDOSWJOEkKPS75BU" target="_blank"><img src="https://asciinema.org/a/BBxuvJnfnCDOSWJOEkKPS75BU.svg" /></a>

<a href="https://asciinema.org/a/Ha676xCE1NK9KGmSiRUtJFaHE" target="_blank"><img src="https://asciinema.org/a/Ha676xCE1NK9KGmSiRUtJFaHE.svg" /></a>
