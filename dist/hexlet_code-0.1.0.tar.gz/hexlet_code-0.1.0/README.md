### Hexlet tests and linter status:
[![Actions Status](https://github.com/Detya9/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Detya9/python-project-49/actions)
<a href="https://codeclimate.com/github/Detya9/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f946a3d0094fac015ba/maintainability" /></a>
